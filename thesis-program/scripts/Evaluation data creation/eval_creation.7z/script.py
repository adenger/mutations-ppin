#read hgnc symbol to uniprot converter file
hgncToUniprot = {}
with open('HGNC_to_uniprotAC.txt','r') as hgncConverterFile:
    for line in hgncConverterFile:
        row = line.split('\t')
        hgncToUniprot[row[0].rstrip()] = row[1].rstrip()

#read Refseq to dbSNP converter file
refseqToDbSNP = {}
with open('refseq_to_dbsnp.txt','r') as snpConverterFile:
    for line in snpConverterFile:
        row = line.split('\t')
        refseqToDbSNP[row[0].rstrip()] = row[1].rstrip()

#create wildtype uniprot network and mutations file
wtPPIN = []
mutationsList = []
with open('A_original_PPI_table.txt','r') as tableFile:
    for line in tableFile:
        row = line.split('\t')
        symbolA = hgncToUniprot[row[1].rstrip()]
        symbolB = hgncToUniprot[row[6].rstrip()]
        if row[0] == 'Wild-type':    
            wtPPIN.append([symbolA,symbolB])
        else:
            mutation = refseqToDbSNP[row[4].rstrip()]
            if mutation == "NULL":
                continue
            yeastScore = row[8]
            mutationsList.append([mutation,symbolA,symbolB,yeastScore])

#write uniprot PPIN to file
with open('network_wildtype.txt','w+') as wtPPINfile:
    for pair in wtPPIN:
        line = pair[0] +  pair[1]
        wtPPINfile.write(pair[0] + '\t'+ pair[1] + '\n')
        
#write mutations file
with open('mutation_consequences.txt','w+') as mutationsFile:
    for mutation in mutationsList:
        mutationsFile.write(mutation[0] + '\t' + mutation[1] + '\t' + mutation[2] + '\t' + mutation[3] + '\n')
